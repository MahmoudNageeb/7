'use client'
export default function Notes() {
  return (
    <div className="notes-section">
      <div className="section-header">
        <h2 className="section-title">الملاحظات السريعة</h2>
        <button className="btn btn-primary">
          إضافة ملاحظة
        </button>
      </div>
      <p>محتوى الملاحظات سيتم إضافته هنا...</p>
    </div>
  )
}