'use client'
export default function PomodoroTimer() {
  return (
    <div className="pomodoro-timer">
      <h2 className="section-title">مؤقت البومودورو</h2>
      <p>محتوى مؤقت البومودورو سيتم إضافته هنا...</p>
    </div>
  )
}