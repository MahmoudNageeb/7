'use client'
export default function Calendar() {
  return (
    <div className="calendar-section">
      <div className="section-header">
        <h2 className="section-title">التقويم الشهري</h2>
      </div>
      <p>محتوى التقويم سيتم إضافته هنا...</p>
    </div>
  )
}