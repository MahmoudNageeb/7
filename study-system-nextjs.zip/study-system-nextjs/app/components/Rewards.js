'use client'
export default function Rewards() {
  return (
    <div className="rewards-section">
      <div className="section-header">
        <h2 className="section-title">نظام المكافآت</h2>
      </div>
      <p>محتوى المكافآت سيتم إضافته هنا...</p>
    </div>
  )
}