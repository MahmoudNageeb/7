'use client'
export default function Schedule() {
  return (
    <div className="schedule-section">
      <div className="section-header">
        <h2 className="section-title">جدول المذاكرة الأسبوعي</h2>
        <div>
          <button className="btn btn-warning">
            إجازة
          </button>
          <button className="btn btn-danger">
            إعادة تعيين
          </button>
        </div>
      </div>
      <p>محتوى جدول المذاكرة الكامل سيتم إضافته هنا...</p>
    </div>
  )
}