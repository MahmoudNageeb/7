'use client'
export default function Settings() {
  return (
    <div className="schedule-section">
      <div className="section-header">
        <h2 className="section-title">إعدادات النظام</h2>
      </div>
      <p>محتوى الإعدادات سيتم إضافته هنا...</p>
    </div>
  )
}