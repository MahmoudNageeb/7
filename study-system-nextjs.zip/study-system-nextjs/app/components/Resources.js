'use client'
export default function Resources() {
  return (
    <div className="link-page">
      <div className="section-header">
        <h2 className="section-title">إدارة الروابط الخارجية</h2>
      </div>
      <p>محتوى إدارة الروابط سيتم إضافته هنا...</p>
    </div>
  )
}