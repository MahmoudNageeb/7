'use client'
export default function Stats() {
  return (
    <div className="schedule-section">
      <div className="section-header">
        <h2 className="section-title">إحصائيات وتقارير الأداء</h2>
      </div>
      <p>محتوى الإحصائيات سيتم إضافته هنا...</p>
    </div>
  )
}